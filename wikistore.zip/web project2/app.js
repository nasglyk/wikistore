


const express = require('express')


const app = express()


app.use(express.json());
app.use(express.urlencoded());


const cors = require("cors")
app.use(cors({
    origin: "*"
}))

const bodyParser = require('body-parser');
const multer = require('multer');
var upload = multer();

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.use(upload.array()); 
app.use(express.static('public'));

const users = [{ name: "nassos", password: "1989", sessionId: ""},{ name: "xristina", password: "12", sessionId:""}]

app.get('/users',(req,res)=>{
    res.render('form');
})

app.post('/users', (req, res) => {
    
    const user = { name: req.body.username, password: req.body.password}
   
    let i = 0;
    let id= "";
    do {
       
        if(users[i].name==user.name && users[i].password==user.password){
            console.log("user found")
            const { v4: uuidv4 } = require('uuid');
            id=uuidv4()
            users[i].sessionId=id;
            res.send({ "sessionId": id }
                )
    }

    i++;
   
    } while (i < users.length);
    
    console.log(users);
    //
    
});


app.post('/cart', (req, res) => {
    
    const user = req.body.sessionId
    console.log(user)
    res.send({ "yas": "test" })
    
    
});






app.listen(5000)