window.addEventListener('load', init);
const queryString = window.location.search;
const urlParams = new URLSearchParams(queryString);
const product = urlParams.get('categoryId');

function init() {
    const queryString = window.location.search;
    console.log(queryString + "yas")
    
    console.log(product)
    renderCategories();


    let categoriesTemplateScript = document.getElementById('categories-template').textContent;
    window.templates = {}
    window.templates.categoriesTable = Handlebars.compile(categoriesTemplateScript)
    

    /*
    let productsTemplateScript = document.getElementById('products-template').textContent;
    window.templates2 = {}
    window.templates2.productsTable = Handlebars.compile(productsTemplateScript)*/

}



async function getCategories() {

    let url = 'https://wiki-shop.onrender.com/categories';
    
    if(product!= null){
        url = 'https://wiki-shop.onrender.com/categories/' + product+ '/products';
        
    }
    try {
        
        let res = await fetch(url);
        return await res.json();
    } catch (error) {
        console.log(error);
    }
}







async function getSubcategories() {

    let url = 'https://wiki-shop.onrender.com/categories';
    
    if(product!= null){
        url = 'https://wiki-shop.onrender.com/categories/' + product+ '/subcategories';
        
    }
    try {
        
        let res2 = await fetch(url);
        return await res2.json();
    } catch (error) {
        console.log(error);
    }
}




let subcategoriesObj;
let categoriesObj
async function renderCategories() {
    
    categoriesObj = await getCategories();
    console.log(categoriesObj[0])
    console.log(categoriesObj[0]['id'])
    if(product!=null){
    subcategoriesObj = await getSubcategories();
    console.log(subcategoriesObj[0] + "yaaaaaaas")
    }
    let categoriesTable = document.getElementById("categories-table");
    // countriesJSON is a global variable loaded from countries.js script
    

    let tableHTMLContent = templates.categoriesTable({
        array: categoriesObj, array2: subcategoriesObj /* isos na mporo na valo kai to allo array px array2 */
    });
    categoriesTable.innerHTML = tableHTMLContent;



}



async function chosen_category(id){
    
    if(id!=0){
    console.log(id)
    let subcat = [];

    for (i = 0; i < categoriesObj.length; i++) {
        if(categoriesObj[i]['subcategory_id']==id){
            subcat[i]= categoriesObj[i]
        }
      }

      let categoriesTable = document.getElementById("categories-table");

    
      let tableHTMLContent = templates.categoriesTable({
        array: subcat, array2: subcategoriesObj /* isos na mporo na valo kai to allo array px array2 */
    });
    categoriesTable.innerHTML = tableHTMLContent;
    }else{
        let categoriesTable = document.getElementById("categories-table");
    // countriesJSON is a global variable loaded from countries.js script
    

    let tableHTMLContent = templates.categoriesTable({
        array: categoriesObj, array2: subcategoriesObj /* isos na mporo na valo kai to allo array px array2 */
    });
    categoriesTable.innerHTML = tableHTMLContent;
    }
    const yesBtn = document.getElementById(id);
    yesBtn.checked = true;

}

let myHeaders = new Headers();
myHeaders.append('Content-Type', 'application/x-www-form-urlencoded');




/*form.addEventListener('submit', function(e) {
    e.preventDefault();
*/
async function mpourda(){
    let form = document.getElementById('form');
    let payload = new FormData(form);
    let formStr=new URLSearchParams(payload)
    console.log([...payload]);


    let init = {
        method: "POST",
        headers: myHeaders,
        body: formStr

    }

    fetch('http://httpbin.org/post',init)

        .then(response => {
            console.log('Succeeded:', response.ok)
        })
        .catch(error => {
            console.log(error)
        })
//})
}